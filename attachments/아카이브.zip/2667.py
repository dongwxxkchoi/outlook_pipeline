from collections import deque

N = int(input())
town_map = [[0 for _ in range(N)] for _ in range(N)]
visited = [[False for _ in range(N)] for _ in range(N)]
town_cnt = 0
town_list = []
dxs = [0, 1, 0, -1]
dys = [1, 0, -1, 0]

for y in range(N):
    line = input()
    for x in range(N):
        town_map[y][x] = int(line[x])


def bfs(y: int, x: int):
    global town_cnt
    global town_list

    house_cnt = 0
    q = deque()
    q.append((y, x))
    visited[y][x] = True
    house_cnt += 1
    print("start: ", x, y)
    while q:
        loc_x, loc_y = q.popleft()
        for dx, dy in zip(dxs, dys):
            nx, ny = loc_x + dx, loc_y + dy
            if 0 <= nx < N and 0 <= ny < N:
                if town_map[ny][nx] == 1 and visited[ny][nx] is False:
                    visited[ny][nx] = True
                    house_cnt += 1
                    q.append((ny, nx))
                    print("house cnt: ", house_cnt, "nx", ny, "ny", nx)

    town_list.append(house_cnt)
    town_cnt += 1
    print(town_list, town_cnt)



for y in range(N):
    for x in range(N):
        if town_map[y][x] == 1 and visited[y][x] is False:
            bfs(y, x)

print(town_cnt)
print(town_list)


#폴더 -> 문제별
#번호_이름