# 일단 봤을 때 아 DP 구나
# bottom-up 방식

# case 를 나눠서 진행해봐야겠다
# 근데, 3잔을 기준으로 했을 때, 전에 몇개까지 저장을 해야 할까?
# 생각을 해보자
# N잔까지 마셔야 한다고 생각을 할 떄,
# 일단 3잔 연속이 기준이니 3잔을 제외하고는 최대라고 카운트해보자
# N-3잔까지의 최대량은 M

# 현재 포함 4잔을 제외하고 최대라고 카운트하자
# N-4잔까지의 최대량을 M
# 즉, 4잔을 대상으로 카운트 하는 것이다
# 그럼 그 4잔을 대상으로는 어떻게 카운트해야할까?

# 아니다
# 다시 생각해보니 연속횟수와 량을 카운트하는 것이 쉽겠다
# 예를 들어, N위치의 것을 세야 하는데 N-1까지의 가능한 경우는
# 연속된 것 X, 연속된 것 1, 연속된 것 2 이런 식으로 카운트하는 거다
# 딕셔너리를 통해 업데이트 하면 될 것 같다.
# 결과는 틀렸죠? ㅎ

# 4개를 카운트해보자
# 0011 0101 1001 1010 1100
# 1101 1011



K = int(input())
wines = []
drunk = {0: (0, 0, 0), 1: 0, 2: 0}

for _ in range(K):
    wines.append(int(input()))


def DP(K, wines):
    drunk[0] = (wines[0] + wines[1], wines[0], wines[1])
    drunk[1] = wines[0] + wines[2]
    drunk[2] = wines[1] + wines[2]

    for i in range(3, K):
        new_drunk_0_3 = drunk[]
        new_drunk_0_2 = max([drunk[1]])
        new_drunk_0_1 = max([drunk[0][0], drunk[0][1], drunk[0][2]])
        new_drunk_1 = max([drunk[0][0] + wines[i], drunk[0][1] + wines[i], drunk[0][2] + wines[i]])
        new_drunk_2 = drunk[1] + wines[i]

        drunk[0] = (new_drunk_0_1_1, new_drunk_0_1_2, new_drunk_0_2)
        drunk[1] = new_drunk_1
        drunk[2] = new_drunk_2
        print(drunk)

    print(max([drunk[0][0], drunk[0][1], drunk[1], drunk[2]]))


DP(K, wines)
