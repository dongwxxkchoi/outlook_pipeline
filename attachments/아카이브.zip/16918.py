R, C, N = map(int, input().split())
bomber_map = [[0 for _ in range(C)] for _ in range(R)]
dxs = [1, 0, -1, 0]
dys = [0, 1, 0, -1]

explode_map = [[0 for _ in range(C)] for _ in range(R)]

for i in range(R):
    tmp_line = input()
    for j in range(C):
        if tmp_line[j] == '.':
            continue
        else:
            bomber_map[i][j] = 2


def progress(bomber_map, flag):
    if flag is True:
        for i in range(R):
            for j in range(C):
                if bomber_map[i][j] == 1:
                    explode_map[i][j] = 1
                elif bomber_map[i][j] == 2:
                    bomber_map[i][j] = 1

        for i in range(R):
            for j in range(C):
                if explode_map[i][j] == 1:
                    explode_map[i][j] = 0
                    bomber_map[i][j] = 0
                    for dx, dy in zip(dxs, dys):
                        nx, ny = j + dx, i + dy
                        if 0 <= nx < C and 0 <= ny < R:
                            bomber_map[ny][nx] = 0


    else:
        for i in range(R):
            for j in range(C):
                if bomber_map[i][j] == 2:
                    bomber_map[i][j] = 1
                elif bomber_map[i][j] == 0:
                    bomber_map[i][j] = 2

    # for i in range(R):
    #     print(bomber_map[i])
    #
    # print()

flag = True

for n in range(N, 0,-1):
    progress(bomber_map, flag)
    if flag:
        flag = False
    else:
        flag = True

for i in range(R):
    for j in range(C):
        if bomber_map[i][j] == 0:
            print('.', end='')
        else:
            print('O', end='')
    print()