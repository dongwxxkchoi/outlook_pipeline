from collections import deque

T = int(input())

for iter in T:
    M, N, K = map(int, input().split())
    farm = [[0 for _ in range(M)] for _ in range(N)]
    visited = [[False for _ in range(M)] for _ in range(N)]
    q = deque()
    dxs = [0, 1, 0, -1]
    dys = [1, 0, -1, 0]
    count = 0

    for i in range(K):
        x, y = map(int, input().split())
        farm[x][y] = 1

    q.append((0, 0))

    while q:
        loc_x, loc_y = q.popleft()
        if farm[loc_x][loc_y] == 1:
            count += 1

        for dx, dy in zip(dxs, dys):
            if M >= loc_x + dx >= 0 and N >= loc_y + dy >= 0:
                q.append((loc_x+dx, loc_y+dy))


def dfs(x, y):
    if visited[x][y] == 0:
        visited[x][y] = 1

        for i in range(4):
            nx = x + dx[i]
            ny = y + dy[i]

            if nx < 0 or nx > (N-1) or ny < 0 or ny > (M-1):
                continue
            elif visited[nx][ny] == 1:
                continue

            else:
                print(nx, ny)
                dfs(nx, ny)
        return True

    else:
        return False