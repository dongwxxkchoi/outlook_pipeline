# 엥 무슨 소리지?
# A -> B -> BA -> BAB -> BABBA -> BABBABAB ->
# B의 개수 check -> B와 A가 하나씩 증가
# A의 개수 check -> A가 하나씩 증가
# 그렇다면 전 대의 B와 A의 개수만 count하면 되는 거 아닌가?

# 가장 최근 것이 바뀌는 것이 아니라 모든 string이
# A의 경우 B로, B의 경우 BA로 바뀌는구나!

# 그러면 어떻게 해야 하지, 이게 실버5라고?
# 생각해보면 A -> B -> BA -> BAB -> BABBA 이 흐름이 전체에 걸쳐 나타나는 것
# 마치 피보나치와 같은 느낌

K = int(input())
# K번 만큼 버튼을 누를 것

DP_table = {"A": 1, "B": 0}

def DP(K, DP_table):
    for _ in range(K):
        new_B = DP_table["A"] + DP_table["B"]
        new_A = DP_table["B"]

        DP_table["A"] = new_A
        DP_table["B"] = new_B

    print(DP_table["A"], DP_table["B"])

DP(K, DP_table)